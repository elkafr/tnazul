
import 'hex_color.dart';

final mainAppColor = HexColor('63B77B');
final hintColor = HexColor('B1B1B1');
final accentColor = HexColor('F3F3F3');
final toastWarningColor = HexColor('FF1937');
final omar = HexColor('C5C5C5');
